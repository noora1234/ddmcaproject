﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcApplication2.Models
{
    public class customer
    {
        public String Cname { get; set; }
        public String Cemail { get; set; }
        public String Cphone { get; set; }
        
    }
}