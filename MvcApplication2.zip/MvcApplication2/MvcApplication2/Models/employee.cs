﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MvcApplication2.Models
{
    public class employee
    {
        [Required]
        [Display(Name="Employee Name")]
        [RegularExpression("[a-zA-Z]+\\.?",ErrorMessage="invalid name")]
        public String Ename { get; set; }
        [Required]
        [Display(Name = "Email address")]
        [DataType(DataType.EmailAddress,ErrorMessage="enter valid email")]
        public String Eemail { get; set; }
        [Required]
        [Display(Name = "Enter address")]
        [DataType(DataType.MultilineText)]
        public String Eaddress { get; set; }
        [Required]
        [Display(Name = "Enter salary")]
        [Range(1000,10000,ErrorMessage="enter valid amount")]
        public String Esalary { get; set; }
    }
}