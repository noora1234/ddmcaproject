﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication3.Models;
namespace MvcApplication3.Controllers
{
    public class TestController : Controller
    {
        //
        // GET: /Test/

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult getString()
        {
            return View();
        }

        public ActionResult myStudent()
        {
            Student s = new Student();
           s.Sname="ajmal";
            s.Semail="amal jyothi.ac.in";
            return View(s);
        }
       /* public ActionResult myStudent()
        {
            student s = new student();
        
            return View(s);
        }*/
       
    }
}
