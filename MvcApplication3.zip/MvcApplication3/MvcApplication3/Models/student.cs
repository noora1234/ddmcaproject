﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace MvcApplication3.Models
{
     public class Student
    {
        [Required]
        [Display(Name="Employee Name")]
        [RegularExpression("4567abc")]
        public string Sname { get; set; }
        [Required]
        [DataType(DataType.MultilineText, ErrorMessage = "Invalid Address")]
        [MaxLength(30,ErrorMessage="Max 30 Characters")]
        public string address { get; set; }
        [Required]
        [Display(Name = "Employee Email")]
        [DataType(DataType.EmailAddress,ErrorMessage="Invalid Email")]
        public string Semail { get; set; }
        [Required]
        [Display(Name = "Employee Salary")]
        [Range(1000,10000)]
        public string salary { get; set; }
     


    }
}
   