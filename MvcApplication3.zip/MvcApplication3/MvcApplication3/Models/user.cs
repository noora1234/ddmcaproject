﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MvcApplication3.Models
{
    public class user
    {
        public int Id { get; set; }
        [Required]
        [Display(Name = " Enter Username")]
        [RegularExpression("^[a-z0-9_-]{3,15}$", ErrorMessage = "Enter valid username")]
        public String Uname { get; set; }
        [Required]
        [Display(Name = "Enter Password")]
        [DataType(DataType.Password, ErrorMessage = "enter valid password")]
        public String Pswd { get; set; }
    }
}