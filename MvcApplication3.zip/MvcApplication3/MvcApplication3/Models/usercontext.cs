﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace MvcApplication3.Models
{
    public class usercontext:DbContext
    {
        public usercontext()
            :base("conn")
        {
        DropCreateDatabaseIfModelChanges<usercontext>d=new DropCreateDatabaseIfModelChanges<usercontext>();
        Database.SetInitializer<usercontext>(d);
        }
    public DbSet<user>Users{get; set;}

    }  
}