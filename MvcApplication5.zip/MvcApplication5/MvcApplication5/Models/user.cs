﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace MvcApplication5.Models
{
    public class user
    {
       
        [Required]
        [Display(Name="user name")]
        [DataType(DataType.EmailAddress, ErrorMessage = "Invalid Email")]
        [RegularExpression("4567abc")]
        public string name { get; set; }
        [Required]
        [Display(Name = "password")]
        [DataType(DataType.Password, ErrorMessage = "Invalid password")]
        public string password { get; set; }


    }
}