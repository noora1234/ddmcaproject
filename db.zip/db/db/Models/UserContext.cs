﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace db.Models
{
    public class UserContext : DbContext
    {
        public UserContext()
            : base("con")
        {
            DropCreateDatabaseIfModelChanges<UserContext> d = new DropCreateDatabaseIfModelChanges<UserContext>();
            Database.SetInitializer<UserContext>(d);
        }
        public DbSet<UserDemo> Userdemos { get; set; }

        public System.Data.Entity.DbSet<db.Models.Student> Students { get; set; }
    }
}