﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace db.Models
{
    public class UserDemo
    {
        public String UserDemoId { get; set; }
        [Required]
        [Display(Name="Enter your name")]
        public String uname { get; set; }
        [Required]
        [MaxLength(6,ErrorMessage="maximum charecters 6 to8")]
        public String password { get; set; }
    }
}