﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using dude.Models;

namespace dude.Controllers
{
    public class dudeController : Controller
    {
        //
        // GET: /dude/

        public ActionResult Index()
        {

            return View();
        }
        public ActionResult getString()
        {
            return View();
        }
        public ActionResult mystudent()
        {
            sudent s = new sudent();
            s.Sname="dfg";
            s.Semail="edrtfty";

            return View(s);
        }
        public ActionResult getcustomer()
        {
            return View();
        }
        public ActionResult getemployee()
        {
            return View();
        }
        

    }
}
