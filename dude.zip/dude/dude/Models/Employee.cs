﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace dude.Models
{
    public class Employee
    {
        [Required]
    [Display(Name="emlpoyee nam")]

        public String name { get; set; }
         [Display(Name="email address")]
        [DataType(DataType.EmailAddress)]
        public String email { get; set; }
          [Display(Name="emloyee address")]
        [DataType(DataType.MultilineText)]
        public String adress { get; set; }
        public String phone{ get; set; }
    }
}