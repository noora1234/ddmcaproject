﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace dude.Models
{
    public class customer
    {
        public String Sname { get; set; }
        public String Semail { get; set; }
        public String Sphone { get; set; }
    }
}