﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace dude.Models
{
    public class sudent
    {
        public String Sname { get; set; }
        public String Semail{ get; set; }
    }

  
}